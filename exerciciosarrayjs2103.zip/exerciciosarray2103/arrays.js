//EX 1
/*
const frutas = ["Maçã", "Banana", "Laranja", "Uva", "Manga"];
console.log("Tamanho do array:", frutas.length);
console.log("Terceira fruta:", frutas[2]);

//EX 2
const numeros = [10, 20, 30, 40, 50];
const soma = numeros.reduce((acc, num) => acc + num, 0);
const media = soma / numeros.length;
console.log("Média dos números:", media);

numeros.push(60);
console.log("Array após adicionar um número:", numeros);

numeros.pop();
console.log("Array após remover o último número:", numeros);

numeros.shift();
console.log("Array após remover o primeiro número:", numeros);

//EX 3
const jogadores = [
    { nome: 'João', pontos: 0 },
    { nome: 'Maria', pontos: 0 },
    { nome: 'Carlos', pontos: 0 },
    { nome: 'Ana', pontos: 0 }
  ];
  
  jogadores[1].pontos = 10; 
  
  console.log("Array de jogadores atualizado:", jogadores);
  
//EX 4
const palavras = ["sol", "lua", "estrela", "planeta", "cometa"];

const palavraBuscada = "estrela"; 
const indice = palavras.indexOf(palavraBuscada);

if (indice !== -1) {
  console.log(`A palavra "${palavraBuscada}" está presente no índice ${indice}.`);
} else {
  console.log("Palavra não encontrada.");
}

//EX 5
const pessoas = [
    ["João", 25, "São Paulo"],
    ["Maria", 30, "Rio de Janeiro"],
    ["Carlos", 35, "Belo Horizonte"]
  ];
  
const nomeSegundaPessoa = pessoas[1][0];
const cidadeSegundaPessoa = pessoas[1][2]; 
  
console.log(`Nome: ${nomeSegundaPessoa}, Cidade: ${cidadeSegundaPessoa}`);

*/
